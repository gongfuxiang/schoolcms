<?php

/**
 * 模块语言包-成绩
 * @author   Devil
 * @blog     http://gong.gg/
 * @version  0.0.1
 * @datetime 2016-12-01T21:51:08+0800
 */
return array(
	// 添加/编辑
	'score_add_name'					=>	'成绩添加',
	'score_edit_name'				=>	'成绩编辑',
);
?>