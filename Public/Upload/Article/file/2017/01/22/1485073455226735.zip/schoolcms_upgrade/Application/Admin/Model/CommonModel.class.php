<?php

namespace Admin\Model;
use Think\Model;

/**
 * 后台公共模型
 * @author   Devil
 * @blog     http://gong.gg/
 * @version  0.0.1
 * @datetime 2016-12-01T21:51:08+0800
 */
class CommonModel extends Model
{
	
}
?>