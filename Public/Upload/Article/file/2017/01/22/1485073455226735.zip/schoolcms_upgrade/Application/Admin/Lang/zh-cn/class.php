<?php

/**
 * 模块语言包-班级
 * @author   Devil
 * @blog     http://gong.gg/
 * @version  0.0.1
 * @datetime 2016-12-01T21:51:08+0800
 */
return array(
	// 添加/编辑
	'class_add_name'					=>	'班级添加',
	'class_edit_name'					=>	'班级编辑',
);
?>