<?php

/**
 * 模块语言包-学期
 * @author   Devil
 * @blog     http://gong.gg/
 * @version  0.0.1
 * @datetime 2016-12-01T21:51:08+0800
 */
return array(
	// 添加/编辑
	'semester_add_name'					=>	'学期添加',
	'semester_edit_name'				=>	'学期编辑',
);
?>