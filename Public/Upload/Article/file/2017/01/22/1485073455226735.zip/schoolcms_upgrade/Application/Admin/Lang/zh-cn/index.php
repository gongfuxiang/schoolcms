<?php

/**
 * 模块语言包-首页
 * @author   Devil
 * @blog     http://gong.gg/
 * @version  0.0.1
 * @datetime 2016-12-01T21:51:08+0800
 */
return array(
	// 列表
	'server_ver_nam	'					=>	'服务器信息',
	'php_ver_name'						=>	'PHP版本',
	'mysql_ver_name'					=>	'MySQL版本',
	'os_ver_name'						=>	'操作系统',
	'host_name'							=>	'当前域名',
	'ver_name'							=>	'软件版本',
	'server_ver_name'					=>	'服务器端信息',
	'ver_to_view_name'					=>	'查看最新版本',
	'copyright_name'					=>	'版权所有',
	'originator_name'					=>	'发起人',
	'research_name'						=>	'研发成员',
	'ued_name'							=>	'UED',
	'market_operation'					=>	'市场运作',
	'os_view_title'						=>	'系统信息',
	'team_view_title'					=>	'开发团队',
);
?>